// deno-lint-ignore-file no-explicit-any
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/google_maps';
const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
const GOOGLE_MAPS_API_KEY = Deno.env.get('GOOGLE_MAPS_API_KEY');

function toRad(v: number) { return (v * Math.PI) / 180; }
function haversine(a: {lat:number,lng:number}, b: {lat:number,lng:number}) {
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s = Math.sin(dLat/2)**2 + Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

async function gmaps(path: string, init: RequestInit & { fieldMask?: string } = {}) {
  const headers: Record<string, string> = {
    'Authorization': `Bearer ${LOVABLE_API_KEY}`,
    'X-Connection-Api-Key': GOOGLE_MAPS_API_KEY!,
    'Content-Type': 'application/json',
  };
  if (init.fieldMask) headers['X-Goog-FieldMask'] = init.fieldMask;
  const res = await fetch(`${GATEWAY_URL}${path}`, { ...init, headers: { ...headers, ...(init.headers || {}) } });
  const body = await res.text();
  if (!res.ok) throw new Error(`[${res.status}] ${body}`);
  return JSON.parse(body);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    if (!LOVABLE_API_KEY || !GOOGLE_MAPS_API_KEY) throw new Error('Missing Google Maps credentials');
    const { hallName, wilaya } = await req.json();
    if (!hallName || typeof hallName !== 'string') {
      return new Response(JSON.stringify({ error: 'hallName مطلوب' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // 1) Find the hall via Text Search restricted to Oman
    const query = `${hallName}${wilaya ? ' ' + wilaya : ''} قاعة أفراح سلطنة عمان`;
    const hallRes: any = await gmaps('/places/v1/places:searchText', {
      method: 'POST',
      fieldMask: 'places.id,places.displayName,places.formattedAddress,places.location',
      body: JSON.stringify({
        textQuery: query,
        languageCode: 'ar',
        regionCode: 'OM',
        maxResultCount: 1,
      }),
    });
    const hall = hallRes.places?.[0];
    if (!hall) {
      return new Response(JSON.stringify({ error: 'لم يتم العثور على القاعة' }), { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const hallLoc = { lat: hall.location.latitude, lng: hall.location.longitude };

    // 2) Nearby hotels & lodging within 15km
    const nearbyRes: any = await gmaps('/places/v1/places:searchNearby', {
      method: 'POST',
      fieldMask: 'places.id,places.displayName,places.formattedAddress,places.location,places.rating,places.userRatingCount,places.primaryType,places.types',
      body: JSON.stringify({
        includedTypes: ['hotel', 'resort_hotel', 'extended_stay_hotel', 'motel', 'bed_and_breakfast', 'guest_house', 'inn', 'hostel'],
        maxResultCount: 20,
        languageCode: 'ar',
        regionCode: 'OM',
        locationRestriction: {
          circle: { center: { latitude: hallLoc.lat, longitude: hallLoc.lng }, radius: 15000 },
        },
        rankPreference: 'DISTANCE',
      }),
    });

    // Filter out private homes / non-commercial lodging just in case
    const ALLOWED = new Set(['hotel','resort_hotel','extended_stay_hotel','motel','bed_and_breakfast','guest_house','inn','hostel']);
    const BLOCKED = new Set(['rooming_house','private_guest_room','campground','cottage','farmstay','chalet','house','apartment_complex']);
    (nearbyRes as any).places = (nearbyRes.places || []).filter((p: any) => {
      const types: string[] = p.types || [];
      if (types.some((t) => BLOCKED.has(t))) return false;
      if (p.primaryType && ALLOWED.has(p.primaryType)) return true;
      return types.some((t) => ALLOWED.has(t));
    });

    let places = (nearbyRes.places || []).map((p: any) => {
      const loc = { lat: p.location.latitude, lng: p.location.longitude };
      return {
        id: p.id,
        name: p.displayName?.text || 'بدون اسم',
        address: p.formattedAddress,
        rating: p.rating,
        ratingCount: p.userRatingCount,
        types: p.types || [],
        primaryType: p.primaryType,
        location: loc,
        distanceKm: +haversine(hallLoc, loc).toFixed(2),
        durationMin: null as number | null,
        drivingKm: null as number | null,
      };
    });

    // 3) Travel duration & driving distance via Routes API (computeRouteMatrix)
    if (places.length) {
      try {
        const matrix: any = await gmaps('/routes/v2:computeRouteMatrix', {
          method: 'POST',
          fieldMask: 'originIndex,destinationIndex,duration,distanceMeters,condition',
          body: JSON.stringify({
            origins: [{ waypoint: { location: { latLng: { latitude: hallLoc.lat, longitude: hallLoc.lng } } } }],
            destinations: places.map((p) => ({
              waypoint: { location: { latLng: { latitude: p.location.lat, longitude: p.location.lng } } },
            })),
            travelMode: 'DRIVE',
            routingPreference: 'TRAFFIC_AWARE',
          }),
        });
        const rows: any[] = Array.isArray(matrix) ? matrix : (matrix.elements || matrix || []);
        for (const row of rows) {
          if (row?.condition && row.condition !== 'ROUTE_EXISTS') continue;
          const idx = row?.destinationIndex;
          if (typeof idx !== 'number' || !places[idx]) continue;
          const secs = typeof row.duration === 'string' ? parseInt(row.duration) : row.duration?.seconds;
          if (secs) places[idx].durationMin = Math.round(secs / 60);
          if (row.distanceMeters) places[idx].drivingKm = +(row.distanceMeters / 1000).toFixed(2);
        }
      } catch (err) {
        console.warn('route matrix failed, falling back to haversine only:', err);
      }
    }

    places.sort((a, b) => {
      if (a.distanceKm !== b.distanceKm) return a.distanceKm - b.distanceKm;
      const da = a.durationMin ?? Number.POSITIVE_INFINITY;
      const db = b.durationMin ?? Number.POSITIVE_INFINITY;
      return da - db;
    });

    return new Response(JSON.stringify({
      hall: {
        id: hall.id,
        name: hall.displayName?.text,
        address: hall.formattedAddress,
        location: hallLoc,
      },
      places,
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e: any) {
    console.error('find-nearby-hotels error:', e?.message || e);
    return new Response(JSON.stringify({ error: e?.message || String(e) }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
