import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Search, MapPin, Building2, Star, Navigation, Loader2, Sparkles } from "lucide-react";

const WILAYAT = [
  "مسقط","مطرح","بوشر","السيب","العامرات","قريات","صحار","صحم","لوى","شناص","الخابورة","السويق","المصنعة","بركاء","نزوى","بهلاء","منح","إزكي","سمائل","بدبد","صور","الكامل والوافي","جعلان بني بو علي","جعلان بني بو حسن","الرستاق","العوابي","نخل","وادي المعاول","صلالة","طاقة","مرباط","ثمريت","سمد الشأن","المضيبي","إبراء","الظاهرة","عبري","ينقل","ضنك","خصب","دبا","مدحاء","بخاء"
];

type Place = {
  id: string; name: string; address?: string; rating?: number; ratingCount?: number;
  types: string[]; primaryType?: string; location: { lat: number; lng: number };
  distanceKm: number; durationMin?: number | null; drivingKm?: number | null;
};

const typeLabel = (t?: string) => {
  const m: Record<string, string> = {
    hotel: "فندق", motel: "موتيل", resort_hotel: "منتجع", extended_stay_hotel: "شقق فندقية",
    bed_and_breakfast: "نُزل", guest_house: "بيت ضيافة", lodging: "إقامة",
  };
  return t ? (m[t] || "إقامة") : "إقامة";
};

const Index = () => {
  const [hallName, setHallName] = useState("");
  const [wilaya, setWilaya] = useState("");
  const [loading, setLoading] = useState(false);
  const [hall, setHall] = useState<{ name: string; address?: string } | null>(null);
  const [places, setPlaces] = useState<Place[]>([]);
  const [filter, setFilter] = useState("");

  const nearest = places[0];

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!hallName.trim()) { toast.error("يرجى إدخال اسم القاعة"); return; }
    setLoading(true);
    setPlaces([]); setHall(null);
    try {
      const { data, error } = await supabase.functions.invoke("find-nearby-hotels", {
        body: { hallName: hallName.trim(), wilaya: wilaya.trim() },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setHall(data.hall);
      setPlaces(data.places || []);
      if (!data.places?.length) toast.info("لم يتم العثور على فنادق قريبة");
      else toast.success(`تم العثور على ${data.places.length} إقامة قريبة`);
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || "حدث خطأ في البحث");
    } finally {
      setLoading(false);
    }
  };

  const filtered = places.filter(p =>
    !filter || p.name.includes(filter) || (p.address || "").includes(filter)
  );

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero opacity-10" />
        <div className="container mx-auto px-4 py-16 md:py-24 relative">
          <div className="max-w-3xl mx-auto text-center animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">مدعوم بخرائط Google</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-black mb-4 leading-tight">
              <span className="text-gradient">قاعات الأفراح</span>
              <br />
              <span className="text-foreground">في سلطنة عُمان</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              ابحث عن قاعة الحفل واعرف أقرب الفنادق والشقق الفندقية مرتبة حسب المسافة
            </p>
          </div>

          {/* Search Card */}
          <Card className="glass max-w-4xl mx-auto p-6 md:p-8 shadow-elegant animate-fade-up border-0">
            <form onSubmit={search} className="grid md:grid-cols-[1fr_1fr_auto] gap-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-primary" /> اسم قاعة الحفل
                </label>
                <Input
                  value={hallName}
                  onChange={(e) => setHallName(e.target.value)}
                  placeholder="مثال: قاعة الأعراس الملكية"
                  className="h-12 text-base border-2 focus-visible:ring-primary"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-accent" /> الولاية (اختياري)
                </label>
                <Input
                  list="wilayat"
                  value={wilaya}
                  onChange={(e) => setWilaya(e.target.value)}
                  placeholder="مثال: مسقط"
                  className="h-12 text-base border-2 focus-visible:ring-primary"
                />
                <datalist id="wilayat">
                  {WILAYAT.map(w => <option key={w} value={w} />)}
                </datalist>
              </div>
              <div className="flex items-end">
                <Button
                  type="submit"
                  disabled={loading}
                  className="h-12 w-full md:w-auto px-8 gradient-hero text-white font-bold shadow-glow hover:opacity-90 transition-all"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Search className="w-5 h-5 ml-2" /> بحث</>}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </header>

      {/* Results */}
      <main className="container mx-auto px-4 pb-20">
        {hall && (
          <div className="max-w-4xl mx-auto mb-8 animate-fade-up">
            <Card className="p-6 border-2 border-primary/20 gradient-card shadow-soft">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">القاعة</div>
                  <h2 className="text-2xl font-black mb-1">{hall.name}</h2>
                  {hall.address && <p className="text-sm text-muted-foreground flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {hall.address}</p>}
                </div>
                {nearest && (
                  <div className="text-right bg-primary/5 rounded-2xl p-4 min-w-[240px]">
                    <div className="text-xs uppercase tracking-wider text-primary font-bold mb-1">أقرب فندق</div>
                    <div className="font-bold text-lg">{nearest.name}</div>
                    <div className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                      <Navigation className="w-3.5 h-3.5" /> يبعد {nearest.distanceKm} كم
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {places.length > 0 && (
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
              <h3 className="text-xl font-bold">
                الفنادق والشقق القريبة <span className="text-muted-foreground font-normal">({filtered.length})</span>
              </h3>
              <Input
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                placeholder="بحث ضمن النتائج..."
                className="max-w-xs h-10"
              />
            </div>

            <div className="grid gap-4">
              {filtered.map((p, i) => (
                <Card
                  key={p.id}
                  className="p-5 gradient-card border hover:border-primary/40 hover:shadow-elegant transition-all group animate-fade-up"
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <div className="flex items-start gap-4">
                    <div className="shrink-0 w-14 h-14 rounded-2xl gradient-hero flex items-center justify-center text-white font-black shadow-glow group-hover:scale-110 transition-transform">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h4 className="font-bold text-lg truncate">{p.name}</h4>
                        <Badge variant="secondary" className="text-xs">{typeLabel(p.primaryType)}</Badge>
                        {p.rating && (
                          <span className="inline-flex items-center gap-1 text-sm text-amber-600 font-semibold">
                            <Star className="w-3.5 h-3.5 fill-current" /> {p.rating}
                            <span className="text-muted-foreground font-normal">({p.ratingCount})</span>
                          </span>
                        )}
                      </div>
                      {p.address && <p className="text-sm text-muted-foreground line-clamp-1 mb-2">{p.address}</p>}
                      <div className="flex flex-wrap items-center gap-3 text-sm">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary font-bold">
                          <Navigation className="w-3.5 h-3.5" /> {p.distanceKm} كم
                        </span>
                        {p.durationMin != null && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/10 text-accent font-bold">
                            ⏱ {p.durationMin} دقيقة{p.drivingKm ? ` · ${p.drivingKm} كم` : ''}
                          </span>
                        )}
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${p.location.lat},${p.location.lng}`}
                          target="_blank" rel="noreferrer"
                          className="text-accent hover:underline font-semibold"
                        >
                          فتح في الخرائط ↗
                        </a>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {!loading && !places.length && !hall && (
          <div className="max-w-md mx-auto text-center py-16 animate-float">
            <div className="w-24 h-24 mx-auto mb-6 rounded-3xl gradient-hero flex items-center justify-center shadow-glow">
              <Building2 className="w-12 h-12 text-white" />
            </div>
            <p className="text-muted-foreground">أدخل اسم قاعة الحفل لعرض أقرب الفنادق والشقق</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Index;
